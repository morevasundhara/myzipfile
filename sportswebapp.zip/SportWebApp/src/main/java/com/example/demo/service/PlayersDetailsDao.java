package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.pojo.Player;
import com.example.demo.repo.MatchesRepo;
import com.example.demo.repo.PlayerRepo;

@Service
public class PlayersDetailsDao {

	@Autowired
	PlayerRepo playerRepo;

	@Autowired
	MatchesRepo matchesRepo;

	@Autowired
	PlayersDetailsService playersDetailsService;

	public List<Player> allPlayers() {
		List<Player> players = playerRepo.findAll();
		return playersDetailsService.removeAdmin(players);
	}

	public List<Player> filterPlayers(MatchesBean matchesBean) {
		List<MatchesBean> matchesBeansList = matchesRepo.findBySportNameAndSubSport(matchesBean.getSportName(),
				matchesBean.getSubSport());
		List<String> UsernameList = playersDetailsService.filterUsername(matchesBeansList);
		return playerRepo.filterPlayer(UsernameList);
	}
}
