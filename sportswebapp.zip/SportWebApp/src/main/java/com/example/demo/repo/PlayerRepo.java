package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.pojo.LoginBean;
import com.example.demo.pojo.Player;

public interface PlayerRepo extends JpaRepository<Player, Integer>{

	public Player findByUserName(String userName);
	public int countByUserName(String userName);
	
	@Query(value="select * from player where user_name in (:username)",nativeQuery =  true)
	public List<Player> filterPlayer(@Param("username") List<String> username);
	
}
