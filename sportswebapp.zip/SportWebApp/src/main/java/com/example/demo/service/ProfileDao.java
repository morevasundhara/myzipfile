package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.pojo.Player;
import com.example.demo.repo.PlayerRepo;

@Service
public class ProfileDao {

	@Autowired
	PlayerRepo playerRepo;
	
	
	public Player myDetail(String userName) {
		return playerRepo.findByUserName(userName);
	}
	
	public Player EditDetail(Player player) {
		return playerRepo.save(player);
	}
}
