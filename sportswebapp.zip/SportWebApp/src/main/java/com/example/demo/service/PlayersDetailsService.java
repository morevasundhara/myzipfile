package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.pojo.Player;

@Service
public class PlayersDetailsService {

	public List<Player> removeAdmin(List<Player> players) {
		List<Player> list = players.stream().filter(player -> player.getUserName().equals("Admin"))
				.collect(Collectors.toList());
		players.removeAll(list);
		return players;
	}

	public List<String> filterUsername(List<MatchesBean> list) {
		List<String> usernameList = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			if ((null != list.get(i).getParticipator() && !list.get(i).getParticipator().isEmpty()))
				usernameList.add(list.get(i).getParticipator());
			if ((null != list.get(i).getOponant() && !list.get(i).getOponant().isEmpty()))
				usernameList.add(list.get(i).getOponant());
		}
		return usernameList;
	}
}
