package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Player;
import com.example.demo.service.ProfileDao;

@CrossOrigin
@RestController
@RequestMapping("/profile")
public class ProfileController {

	@Autowired
	ProfileDao profileDao;
	
	@GetMapping("/myDetail/{userName}")
	public Player myDetail(@PathVariable String userName) {
		Player player =profileDao.myDetail(userName);
		return player;
	}
	@PostMapping("/edit")
	public Player edit(@RequestBody Player player) {
		return profileDao.EditDetail(player);
	}
}
