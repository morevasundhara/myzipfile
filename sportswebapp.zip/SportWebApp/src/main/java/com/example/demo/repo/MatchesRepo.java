package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.MatchesBean;

public interface MatchesRepo extends JpaRepository<MatchesBean, Integer> {

	public List<MatchesBean> findByParticipator(String usename);

	public List<MatchesBean> findBySportNameAndSubSport(String sportName, String subSport);

	public List<MatchesBean> findByOponant(String Oponant);

	public List<MatchesBean> findByWinner(String winner);

	public MatchesBean findByParticipatorAndSportNameAndSubSport(String participator, String sportName,
			String subSport);
	
	public List<MatchesBean> findByWinnerNot(String winner);


}
