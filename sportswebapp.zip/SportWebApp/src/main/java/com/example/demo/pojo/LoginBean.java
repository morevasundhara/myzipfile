package com.example.demo.pojo;

import org.springframework.stereotype.Component;

@Component
public class LoginBean {

	String userName;
	String password;
	public LoginBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginBean(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUseName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginBean [userName=" + userName + ", password=" + password + "]";
	}
	
}
