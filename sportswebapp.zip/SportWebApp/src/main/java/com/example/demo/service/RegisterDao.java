package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.Player;
import com.example.demo.repo.PlayerRepo;

@Service
public class RegisterDao {

	@Autowired
	PlayerRepo playerRepo;
	
	public String register(Player player) {
		playerRepo.save(player);
		return "Congrats you have successfully registered";
	}
}
