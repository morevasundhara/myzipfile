package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.service.MatchesDao;

@CrossOrigin
@RestController
@RequestMapping("/sport")
public class matchesController {

	@Autowired
	MatchesDao matchesDao;
	
	@RequestMapping("/unscheduleMatches/{username}")
	public List<MatchesBean> unscheduleMatches(@PathVariable String username){
		return matchesDao.unscheduleMatches(username);
	}
	@RequestMapping("/unscheduleMatches")
	public List<MatchesBean> unscheduleMatchesAllPlayers(){
		return matchesDao.unscheduleMatchesAllPlayers();
	}
	
	@RequestMapping("/fixMatch")
	public List<MatchesBean> fixMatch(@RequestBody MatchesBean matchesBean){
		return matchesDao.fixMatch(matchesBean);
	}
	
	@RequestMapping("/scheduleMatches/{username}")
	public List<MatchesBean> scheduleMatches(@PathVariable String username){
		return matchesDao.scheduleMatches(username);
	}
	@RequestMapping("/scheduleMatches")
	public List<MatchesBean> scheduledMatchesAllPlayers(){
		return matchesDao.scheduledMatchesAllPlayers();
	}
	
	@RequestMapping("/addScore")
	public List<MatchesBean> addScore(@RequestBody MatchesBean matchesBean){
		return matchesDao.addScore(matchesBean);
	}
	
	@RequestMapping("/matchesHistory/{username}")
	public List<MatchesBean> MatchesHistory(@PathVariable String username){
		return matchesDao.matchesHistry(username);
	}
	
	@RequestMapping("/matchesHistory")
	public List<MatchesBean> matchesHistryAllPlayers(){
		return matchesDao.matchesHistryAllPlayers();
	}
	@RequestMapping("/participate")
	public String addMatch(@RequestBody MatchesBean matchesBean){
		return matchesDao.participate(matchesBean);
	}
}
