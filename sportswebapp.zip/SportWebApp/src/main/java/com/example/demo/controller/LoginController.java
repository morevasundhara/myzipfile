package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.LoginBean;
import com.example.demo.pojo.ReturnLoginObj;
import com.example.demo.service.LoginDao;

@CrossOrigin
@RestController
@RequestMapping("/login")
public class LoginController {

	
	@Autowired
	LoginDao loginDao;
	
	@PostMapping("/login")
	public ReturnLoginObj login(@RequestBody LoginBean loginBean) {
		return loginDao.login(loginBean);
	}
}
