package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.pojo.Player;

@Service
public class matchesService {

	public void setCategory(MatchesBean matchesBean, Player player) {
		if (player.getAge() < 12) {
			matchesBean.setCategory("Junior");
		} else if (player.getAge() < 18) {
			matchesBean.setCategory("Inter");
		} else {
			matchesBean.setCategory("senior");
		}
	}

	public List<MatchesBean> filterUnScheduleMatches(List<MatchesBean> matchesList) {

		List<MatchesBean> filtredList = matchesList.stream().filter(match -> null != match.getParticipator())
				.filter(match -> match.getOponant().isEmpty() || null == match.getOponant())
				.collect(Collectors.toList());
		return filtredList;
	}

	public List<MatchesBean> filterScheduleMatches(List<MatchesBean> matchesList) {

		List<MatchesBean> filtredList = matchesList.stream().filter(match -> null != match.getParticipator())
				.filter(match -> !match.getOponant().isEmpty() && null != match.getOponant() && (null == match.getWinner() || match.getWinner().isEmpty()))
				.collect(Collectors.toList());
		return filtredList;
	}

	public List<MatchesBean> filterMatchesHistry(List<MatchesBean> matchesList) {

		List<MatchesBean> filtredList = matchesList.stream().filter(match -> null != match.getParticipator())
				.filter(match -> !match.getWinner().isEmpty() && null != match.getWinner())
				.collect(Collectors.toList());
		return filtredList;
	}

}
