package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.LoginBean;
import com.example.demo.pojo.Player;
import com.example.demo.pojo.ReturnLoginObj;
import com.example.demo.repo.PlayerRepo;

@Service
public class LoginDao {

	@Autowired
	PlayerRepo playerRepo;
	
	public ReturnLoginObj login(LoginBean loginBean) {
		try {
			System.out.println(loginBean.getUserName());
			System.out.println(playerRepo.countByUserName(loginBean.getUserName()));
			if(playerRepo.countByUserName(loginBean.getUserName())==1){
				Player dbObj = playerRepo.findByUserName(loginBean.getUserName());
				if(dbObj.getPassword().equals(loginBean.getPassword())) {
					return new ReturnLoginObj(2, "", dbObj.getUserName());
				} else {
					return new ReturnLoginObj(1, "Invalid Password", "");
				}
				
			} else {
				return new ReturnLoginObj(1, "Invalid Username", "");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ReturnLoginObj(1, "Something Wrong", "");
		}
	}
}
