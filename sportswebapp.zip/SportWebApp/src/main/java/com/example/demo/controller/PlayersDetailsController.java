package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.pojo.Player;
import com.example.demo.service.PlayersDetailsDao;

@CrossOrigin
@RestController
@RequestMapping("/players")
public class PlayersDetailsController {
	
	@Autowired
	PlayersDetailsDao playersDetailsDao;
	
	@RequestMapping("/allPlayers")
	public List<Player> allPlayers(){
		return playersDetailsDao.allPlayers();
	}
	@RequestMapping("/filterPlayers")
	public List<Player> filterPlayers(@RequestBody MatchesBean matchesBean){
		return playersDetailsDao.filterPlayers(matchesBean);
	}

}