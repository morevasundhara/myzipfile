package com.example.demo.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
public class MatchesBean {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String sportName;
    String subSport;
    String participator;
    String oponant;
    String category;
    int oponantScore;
    int participatorScore;
    String winner;
	public MatchesBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MatchesBean(int id, String sportName, String subSport, String participator, String oponant, String category,
			int oponantScore, int participatorScore, String winner) {
		super();
		this.id = id;
		this.sportName = sportName;
		this.subSport = subSport;
		this.participator = participator;
		this.oponant = oponant;
		this.category = category;
		this.oponantScore = oponantScore;
		this.participatorScore = participatorScore;
		this.winner = winner;
	}

	public String getSportName() {
		return sportName;
	}
	public void setSportName(String sportName) {
		this.sportName = sportName;
	}
	public String getSubSport() {
		return subSport;
	}
	public void setSubSport(String subSport) {
		this.subSport = subSport;
	}
	public String getParticipator() {
		return participator;
	}
	public void setParticipator(String participator) {
		this.participator = participator;
	}
	public String getOponant() {
		return oponant;
	}
	public void setOponant(String oponant) {
		this.oponant = oponant;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getOponantScore() {
		return oponantScore;
	}
	public void setOponantScore(int oponantScore) {
		this.oponantScore = oponantScore;
	}
	public int getParticipatorScore() {
		return participatorScore;
	}
	public void setParticipatorScore(int participatorScore) {
		this.participatorScore = participatorScore;
	}
	public String getWinner() {
		return winner;
	}
	public void setWinner(String winner) {
		this.winner = winner;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "MatchesBean [id=" + id + ", sportName=" + sportName + ", subSport=" + subSport + ", participator="
				+ participator + ", oponant=" + oponant + ", category=" + category + ", oponantScore=" + oponantScore
				+ ", participatorScore=" + participatorScore + ", winner=" + winner + "]";
	}
    
}
