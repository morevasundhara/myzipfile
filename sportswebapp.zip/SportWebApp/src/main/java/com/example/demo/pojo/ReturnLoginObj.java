package com.example.demo.pojo;

import org.springframework.stereotype.Component;

@Component
public class ReturnLoginObj {

	 int status; //1-fail, 2-success
	 String errorMsg;
	 String userName;
	public ReturnLoginObj() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReturnLoginObj(int status, String errorMsg, String userName) {
		super();
		this.status = status;
		this.errorMsg = errorMsg;
		this.userName = userName;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "ReturnLoginObj [status=" + status + ", errorMsg=" + errorMsg + ", userName=" + userName + "]";
	} 
	 
}
