package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.pojo.MatchesBean;
import com.example.demo.pojo.Player;
import com.example.demo.repo.MatchesRepo;
import com.example.demo.repo.PlayerRepo;

@Service
public class MatchesDao {

	@Autowired
	MatchesRepo matchesRepo;
	@Autowired
	PlayerRepo playerRepo;
	@Autowired
	matchesService matchesService;

	public String participate(MatchesBean matchesBean) {
		Player player = playerRepo.findByUserName(matchesBean.getParticipator());
		matchesService.setCategory(matchesBean, player);
		matchesRepo.save(matchesBean);
		return "Participated succussfully";
	}

	public List<MatchesBean> unscheduleMatches(String username) {
		List<MatchesBean> matchesList = matchesRepo.findByParticipator(username);
		return matchesService.filterUnScheduleMatches(matchesList);
	}

	public List<MatchesBean> scheduleMatches(String username) {
		List<MatchesBean> matchesList = matchesRepo.findByParticipator(username);
		return matchesService.filterScheduleMatches(matchesList);
	}

	public List<MatchesBean> matchesHistry(String username) {
		List<MatchesBean> matchesList = matchesRepo.findByParticipator(username);
		return matchesService.filterMatchesHistry(matchesList);
	}

	public List<MatchesBean> unscheduleMatchesAllPlayers() {
		return matchesRepo.findByOponant("");
	}

	public List<MatchesBean> fixMatch(MatchesBean participator) {
		MatchesBean oponant=matchesRepo.findByParticipatorAndSportNameAndSubSport(participator.getOponant(), 
				participator.getSportName(), participator.getSubSport());
		oponant.setOponant(participator.getParticipator());
		matchesRepo.save(oponant);
		matchesRepo.save(participator);
		return unscheduleMatchesAllPlayers();
		
	}

	public List<MatchesBean> scheduledMatchesAllPlayers() {
		return matchesRepo.findByWinner("");
	}

	public List<MatchesBean> addScore(MatchesBean participator) {
		MatchesBean oponant=matchesRepo.findByParticipatorAndSportNameAndSubSport(participator.getOponant(), 
				participator.getSportName(), participator.getSubSport());
		System.out.println("Oponant"+oponant);
		oponant.setOponantScore(participator.getParticipatorScore());
		oponant.setWinner(participator.getWinner());
		matchesRepo.save(oponant);
		matchesRepo.save(participator);
		return scheduledMatchesAllPlayers();
		
	}

	public List<MatchesBean> matchesHistryAllPlayers() {
		return matchesRepo.findByWinnerNot("");
	}

}
